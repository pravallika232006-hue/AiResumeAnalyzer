from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
from pathlib import Path
import sqlite3, re, uuid

BASE=Path(__file__).parent
DB=BASE/"careerlens.db"
UPLOADS=BASE/"uploads"; UPLOADS.mkdir(exist_ok=True)

app=FastAPI(title="CareerLens AI Resume Analyzer")
SKILLS=["python","java","javascript","typescript","react","node.js","fastapi","django","sql","mysql","postgresql","mongodb","docker","aws","azure","git","machine learning","deep learning","nlp","pandas","numpy","scikit-learn","tensorflow","pytorch","streamlit","html","css","tailwind","figma","power bi","tableau","data analysis","excel","c++","c","rest api","linux","kubernetes"]
JOBS=[
{"id":1,"title":"AI / ML Intern","company":"NovaLabs","location":"Remote","type":"Internship","salary":"₹15K–₹25K / month","skills":["python","machine learning","pandas","scikit-learn","sql"]},
{"id":2,"title":"Junior Python Developer","company":"CloudForge","location":"Hyderabad","type":"Full-time","salary":"₹4–7 LPA","skills":["python","fastapi","sql","git","docker"]},
{"id":3,"title":"Frontend Developer Intern","company":"PixelRoute","location":"Bengaluru","type":"Internship","salary":"₹18K–₹30K / month","skills":["javascript","react","html","css","git"]},
{"id":4,"title":"Data Analyst","company":"InsightGrid","location":"Remote","type":"Full-time","salary":"₹5–8 LPA","skills":["python","sql","excel","power bi","data analysis"]},
{"id":5,"title":"NLP Research Intern","company":"MindStack AI","location":"Chennai","type":"Internship","salary":"₹20K–₹35K / month","skills":["python","nlp","machine learning","pytorch","deep learning"]}]

def conn():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def init():
    c=conn()
    c.execute("CREATE TABLE IF NOT EXISTS resumes(id TEXT PRIMARY KEY,name TEXT,score INTEGER,skills TEXT,text TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS applications(id INTEGER PRIMARY KEY AUTOINCREMENT,job_id INTEGER,email TEXT,status TEXT)")
    c.commit(); c.close()
init()

def text_from(name,data):
    ext=Path(name).suffix.lower()
    if ext==".pdf":
        import fitz
        return "\n".join(p.get_text() for p in fitz.open(stream=data,filetype="pdf"))
    if ext==".docx":
        from docx import Document
        import io
        return "\n".join(p.text for p in Document(io.BytesIO(data)).paragraphs)
    return data.decode("utf-8","ignore")

def skills(text):
    low=text.lower()
    return [s for s in SKILLS if re.search(r"(?<!\w)"+re.escape(s)+r"(?!\w)",low)]

def analysis(text):
    ss=skills(text)
    sections={k:bool(re.search(p,text,re.I)) for k,p in {
      "Contact":r"[\w.+-]+@[\w-]+\.[\w.-]+","Education":r"education|b\.?tech|bachelor|degree|university|college",
      "Experience":r"experience|intern|developer|engineer|worked","Projects":r"project|projects"}.items()}
    score=min(100,max(40 if text.strip() else 0,30+len(ss)*5+sum(sections.values())*8))
    return {"score":score,"skills":ss,"sections":sections}

class Match(BaseModel):
    resume_id:str
    job_description:str
class Apply(BaseModel):
    job_id:int
    email:str="demo@careerlens.ai"

@app.get("/")
def home(): return FileResponse(BASE/"static/index.html")
@app.get("/api/health")
def health(): return {"status":"ok"}
@app.get("/api/jobs")
def jobs(q:str=""):
    return [j for j in JOBS if not q or q.lower() in (j["title"]+" "+j["company"]+" "+" ".join(j["skills"])).lower()]
@app.get("/api/resumes")
def resumes():
    c=conn(); rows=c.execute("SELECT id,name,score,skills FROM resumes ORDER BY rowid DESC").fetchall(); c.close()
    return [{"id":r["id"],"name":r["name"],"score":r["score"],"skills":r["skills"].split(",") if r["skills"] else []} for r in rows]
@app.post("/api/analyze")
async def analyze(file:UploadFile=File(...)):
    if not file.filename.lower().endswith((".pdf",".docx",".txt")): raise HTTPException(400,"Use PDF, DOCX or TXT")
    data=await file.read()
    if len(data)>5*1024*1024: raise HTTPException(400,"Maximum file size is 5 MB")
    text=text_from(file.filename,data); r=analysis(text); rid=str(uuid.uuid4())
    c=conn(); c.execute("INSERT INTO resumes VALUES(?,?,?,?,?)",(rid,file.filename,r["score"],",".join(r["skills"]),text)); c.commit(); c.close()
    return {"resume_id":rid,"name":file.filename,**r}
@app.post("/api/match")
def match(x:Match):
    c=conn(); r=c.execute("SELECT * FROM resumes WHERE id=?",(x.resume_id,)).fetchone(); c.close()
    if not r: raise HTTPException(404,"Resume not found")
    rs=set((r["skills"] or "").split(",")); js=set(skills(x.job_description))
    matched=sorted(rs&js); missing=sorted(js-rs); score=round(len(matched)/len(js)*100) if js else 0
    return {"score":score,"matched":matched,"missing":missing,"suggestions":[f"Add genuine evidence for {m} in a project or experience section." for m in missing[:5]]}
@app.post("/api/applications")
def apply(x:Apply):
    c=conn(); c.execute("INSERT INTO applications(job_id,email,status) VALUES(?,?,?)",(x.job_id,x.email,"Applied")); c.commit(); c.close(); return {"ok":True}
@app.get("/api/applications")
def applications():
    c=conn(); rows=c.execute("SELECT * FROM applications ORDER BY id DESC").fetchall(); c.close(); return [dict(r) for r in rows]
@app.get("/api/stats")
def stats():
    c=conn(); a=c.execute("SELECT COUNT(*) n FROM applications").fetchone()["n"]; r=c.execute("SELECT COUNT(*) n FROM resumes").fetchone()["n"]; c.close()
    return {"resumes":r,"applications":a,"jobs":len(JOBS),"users":1250}
