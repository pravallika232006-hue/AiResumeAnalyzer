# CareerLens — Freight-style AI Resume Analyzer

Run:
1. `python -m venv .venv`
2. Windows: `.venv\\Scripts\\activate`
3. `pip install -r requirements.txt`
4. `uvicorn app:app --reload`
5. Open http://127.0.0.1:8000

This is a runnable full-stack-style local product: FastAPI backend + responsive web frontend + SQLite persistence + PDF/DOCX/TXT parsing + ATS scoring + skill extraction + job matching + applications + recruiter/admin views.

The UI is an original freight/logistics SaaS-inspired layout; it does not copy proprietary assets or code.
